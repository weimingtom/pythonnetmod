# Conda Recipe

The files here are needed to build Python.Net with conda

http://conda.pydata.org/docs/building/recipe.html
