# -*- coding: utf-8 -*-

import this_package_should_never_exist_ever
