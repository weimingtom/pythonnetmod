using System.Reflection;
using System.Runtime.CompilerServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Python for .NET")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyDefaultAlias("Python.Runtime.dll")]

[assembly: InternalsVisibleTo("Python.EmbeddingTest")]
